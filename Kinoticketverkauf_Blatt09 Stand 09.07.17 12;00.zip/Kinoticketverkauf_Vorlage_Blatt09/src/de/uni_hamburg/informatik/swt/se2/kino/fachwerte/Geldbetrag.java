package de.uni_hamburg.informatik.swt.se2.kino.fachwerte;

import java.util.regex.Pattern;

public class Geldbetrag
{
    /**
     * Der Euroanteil des Geldbetrags
     */
    private final int _betragEuro;
    
    /**
     * Der Centanteil des Geldbetrags
     */
    private final int _betragCent;
    
    /**
     * Getter Methode für das erzeugen eines neuen Geldgetrags mit getrennten Euro und Cent Beträgen
     * 
     * @param euro Eurobetrag des Geldbetrags
     * @param cent Centbetrag des Geldbetrags
     * @return das neu erzeugte Object von Geldbetrag
     * 
     * @require euro != null
     * @require cent != null
     * @require cent < 100
     * @ensure get(euro, cent) != null
     */
    public static Geldbetrag get(int euro, int cent)
    {
        return new Geldbetrag(euro, cent);
    }
    
    /**
     * Getter Methode für das erzeugen eines neuen Geldbetrags mit geminsamen Eurocentbetrag als String
     * 
     * @param eurocent String für den Eurocentbetrag
     * @return das neu erzeugte Object von Geldbetrag
     * 
     * @require eurocent != null
     * @ensure get(eurocent) != null
     */
    public static Geldbetrag get(String eurocent)
    {
        Pattern p = Pattern.compile(",");
        
        String[] ec = p.split(eurocent);
        
        return new Geldbetrag(Integer.parseInt(ec[0]), Integer.parseInt(ec[1]));
    }
    
    /**
     * Getter Methode für das erzeugen eines neuen Geldbetrags mit gemeinsamen Eurocentbetrag als String
     * 
     * @param eurocent Integer für den Eurocentbetrag
     * @return das neu erzeugte Object von Geldbetrag
     * 
     * @require eurocent != null
     * @ensure get(eurocent) != null
     */
    public static Geldbetrag get(int eurocent)
    {
        String str = Integer.toString(eurocent);
        char[] ec = str.toCharArray();
        
        int cent = ec[ec.length-1] + 10*ec[ec.length-2];
        int euro = 0;
        
        int zähler = 1;
        for (int i = ec.length-3; i == 0; i--)
        {
            euro = euro+ zähler*ec[i];
            zähler ++;
        }
        
        return new Geldbetrag(euro, cent);
    }
    
    /**
     * privater Konstruktor der Klasse Geldbetrag 
     * @param euro Eurobetrag des Geldbetrags
     * @param cent Centbetrag des Geldbetrags
     */
    private Geldbetrag(int euro, int cent)
    {
        _betragEuro = euro;
        _betragCent = cent;
    }
    
    /**
     * Wandelt den Geldbetrag in einen String um
     * 
     * @return den Geldbetrag als String
     */
    public String toString()
    {
        return _betragEuro + "," + _betragCent;
    }
    
    /**
     * Addiert einen Geldbetrag mit einem anderen. 
     * 
     * @param x der zweite Geldbetrag der addiert werden soll
     * @return ein neu erzeugter Geldbetrag mit dem Wert der beiden addierten
     * 
     * @require x != null
     */
    public Geldbetrag add(Geldbetrag x)
    {
        
    }
    
    /**
     * Subtrahiert den zweiten Geldbetrag vom ersten
     * Falls der zweite Geldbetrag größer dem ersten sein sollte wird der absolute Wert des negativen Wertes genommen
     * 
     * @param x der zu subtrahierende Geldbetrag
     * @return ein neu erzeugter Geldbetrag mit dem Wert der beiden verrechneten
     * 
     * @require x != null
     */
    public Geldbetrag sub(Geldbetrag x)
    {
        
    }
    
    /**
     * Multipliziert den Geldbetrag mit einer Integerzahl
     * 
     * @param x die Integerzahl mit der multipliziert werden soll
     * @return ein neu erzeugter Geldbetrag mit dem Ergebnis der Rechnung
     */
    public Geldbetrag mul(int x)
    {
        
    }
    
    /**
     * überprüft auf Gleichheit mit einem Objekt.
     * 
     * @param o ein Object mit dem verglichen werden soll
     * @return boolean-Wert, wenn die Objecte gleich sind, ist er true
     * 
     * @require o != null
     */
    public boolean equals(Object o)
    {
        
    }
    
    /**
     * überprüft zwei Geldbeträge auf Gleichheit
     * 
     * @param andererGeldbetrag der zu vergleichende Geldbetrag
     * @return boolean-Wert, wenn die Geldbeträge gleich sind, ist er true
     * 
     * @require andererGeldbetrag != null
     */
    public boolean equals(Geldbetrag andererGeldbetrag)
    {
        
    }
    
    /**
     * erzeugt einen hashcode des Geldbetrags
     * @return den hashcode
     */
    public int hashcode()
    {
        
    }
    
    /**
     * überprüft ob der ersteBetrag größer-gleich dem zweiten ist
     * @param x der Geldbetrag mit dem verglichen werden soll
     * @return boolean-Wert, wenn der erste größer-gleich dem ersten ist, ist er true
     * 
     * @require x != null
     */
    public boolean greaterEqualsThan(Geldbetrag x)
    {
        
    }
    
    /**
     * erzeugt einen Integer-Wert des Geldbetrags im EuroCent-Muster
     * @return den Geldbetrag als Integer
     */
    public int toInt()
    {
        
    }
}
